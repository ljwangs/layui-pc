function ajaxPost(url,data,funs){
	//检查登陆函数
	var cookRes = checkLogin();
	 userid = cookRes[0];
	 token = cookRes[1];
	$.ajax({
		url: apiurl + url,
		data:data,
		type: "post",
		dataType: "json",
		timeout: 10000, //超时时间设置为10秒； 
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded',
			'userid': userid,
			'token': token
		},
		success: funs,
		error: function(e) {
			layer.closeAll('loading'); //关闭loading
			//异常处理；   
			layer.msg("数据异常", {
				time: 2500,
				anim: 5
			});
		}
	});
}
