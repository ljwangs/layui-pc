//RSA加密
var key ;
function bodyRSA(){
    setMaxDigits(130);
    key = new RSAKeyPair("10001","","b8c24f9cc84d2316f4cad515c1ce3965d9dc82df753f84cb62a5a7e0420f7e9092c4e6e7f5650e42552dbc921b32597dc25c470cf408b6b2c9042e4789cc4eeca512f6d3a0a89c8624709dcecdd8c3addc61fc1187a38b065787c40f189dd35cd1c1c80a813c909fe35a3a714455b7e27596267a652e7f9ba38505afef9d9f99");  
}

//储存 TOKEN USERID USERINFO
function StorageLogin(token,userid,roleId,userName,userLevel){
	localStorage.setItem('token',token);
	localStorage.setItem('userid',userid);
	localStorage.setItem('roleId',roleId);
	localStorage.setItem('userName',userName);
	localStorage.setItem('userLevel',userLevel);
}
//检查登陆函数
function checkLogin(){
	var userid = localStorage.getItem('userid');
	var token = localStorage.getItem('token');
	var roleId = localStorage.getItem('roleId');
	var userName = localStorage.getItem('userName');
	var userLevel = localStorage.getItem('userLevel');
	if(!userid || !token){
		location.href="/changan/login.html";
		return false;
	}
	return [userid,token,roleId,userName,userLevel];
}
/*打开窗口*/
function hrefwebview(url,obj='{}',title="",w='100%',h='100%'){
	//	将json字符串转化为对象    JSON.parse(obj); 
    //	将json对象转化为字符串    JSON.stringify(res); 
	var json = zhuanyi(obj);
    layer.open({
		type: 2,
		title: title,
		shadeClose: true,
		maxmin: false,
		shade: 0.8,
		area: [w, h],
		content: url+"?jsonvalue="+json
	});
}
/*编译|转义JSON参数*///type=0,编译；type=1;转义
/**
 * 替换规则
 * {
	 "=>%S,
	 {=>%Z,
	 }=>%Y,
	 :=>%M
 *  } 
 * **/
function zhuanyi(json,type=0){
   if(type==0){
      var str = json.replace(/\"/g,"%S").replace(/\{/g,"%Z").replace(/\}/g,"%Y").replace(/\:/g,"%M");
      return encode(str);
   }else{
      var str = decode(json);
      return str.replace(/\%S/g,'"').replace(/\%Z/g,"{").replace(/\%Y/g,"}").replace(/\%M/g,":");
       
   }
}
//字符串转base64
function encode(str){
   // 对字符串进行编码
   var encode = encodeURI(str);
   // 对编码的字符串转化base64
   var base64 = btoa(encode);
   return base64;
}
 
// base64转字符串
function decode(base64){
   // 对base64转编码
   var decode = atob(base64);
   // 编码转字符串
   var str = decodeURI(decode);
   return str;
}
/*解析GET值*/
function jiexi(){
	var jsonvalue = GetQueryString("jsonvalue");
	var json = zhuanyi(jsonvalue,1);
	var obj = JSON.parse(json);
	return obj;
}
/*获取GET值*/
function GetQueryString(name)
{
	var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if(r!=null)return  unescape(r[2]); return null;
}
//数组去重
function unique (arr) {
    return Array.from(new Set(arr));
}